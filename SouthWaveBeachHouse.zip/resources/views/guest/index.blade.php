<x-guests-layout>
    <livewire:guest-dashboard />
</x-guests-layout>
