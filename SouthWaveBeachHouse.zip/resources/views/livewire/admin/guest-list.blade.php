<div>
    <div class="bg-white p-10 rounded-xl">
        {{ $this->table }}
    </div>
</div>
