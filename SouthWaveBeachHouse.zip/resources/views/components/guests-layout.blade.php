<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <style>
        [x-cloak] {
            display: none !important;
        }

        .custom-shape-divider-bottom-1695864863 {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            overflow: hidden;
            line-height: 0;
            transform: rotate(180deg);
        }

        .custom-shape-divider-bottom-1695864863 svg {
            position: relative;
            display: block;
            width: calc(100% + 1.3px);
            height: 93px;
        }

        .custom-shape-divider-bottom-1695864863 .shape-fill {
            fill: #ffffff;
        }

        .custom-shape-divider-top-1695878520 {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            overflow: hidden;
            line-height: 0;
        }

        .custom-shape-divider-top-1695878520 svg {
            position: relative;
            display: block;
            width: calc(130% + 1.3px);
            height: 171px;
        }

        .custom-shape-divider-top-1695878520 .shape-fill {
            fill: #FFFFFF;
        }
    </style>
    <!-- Scripts -->
    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>
    @wireUiScripts
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @livewireStyles
    @livewireScripts
    @stack('scripts')
</head>

<body class="font-sans antialiased">
    <div x-data="{ book_modal: false }">
        <div class="mx-auto relative flex max-w-7xl items-center justify-between py-2 lg:px-8">
            <div class="flex space-x-2 items-center">
                <a href="" class="fill-blue-700">
                    <svg version="1.1" id="Icons" class="h-7 w-7" xmlns="http://www.w3.org/2000/svg"
                        xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 32 32" xml:space="preserve">
                        <style type="text/css">
                            .st0 {
                                fill: #FFFFFF;
                            }

                            .st1 {
                                fill: #3A559F;
                            }

                            .st2 {
                                fill: #F4F4F4;
                            }

                            .st3 {
                                fill: #FF0084;
                            }

                            .st4 {
                                fill: #0063DB;
                            }

                            .st5 {
                                fill: #00ACED;
                            }

                            .st6 {
                                fill: #FFEC06;
                            }

                            .st7 {
                                fill: #FF0000;
                            }

                            .st8 {
                                fill: #25D366;
                            }

                            .st9 {
                                fill: #0088FF;
                            }

                            .st10 {
                                fill: #314358;
                            }

                            .st11 {
                                fill: #EE6996;
                            }

                            .st12 {
                                fill: #01AEF3;
                            }

                            .st13 {
                                fill: #FFFEFF;
                            }

                            .st14 {
                                fill: #F06A35;
                            }

                            .st15 {
                                fill: #00ADEF;
                            }

                            .st16 {
                                fill: #1769FF;
                            }

                            .st17 {
                                fill: #1AB7EA;
                            }

                            .st18 {
                                fill: #6001D1;
                            }

                            .st19 {
                                fill: #E41214;
                            }

                            .st20 {
                                fill: #05CE78;
                            }

                            .st21 {
                                fill: #7B519C;
                            }

                            .st22 {
                                fill: #FF4500;
                            }

                            .st23 {
                                fill: #00F076;
                            }

                            .st24 {
                                fill: #FFC900;
                            }

                            .st25 {
                                fill: #00D6FF;
                            }

                            .st26 {
                                fill: #FF3A44;
                            }

                            .st27 {
                                fill: #FF6A36;
                            }

                            .st28 {
                                fill: #0061FE;
                            }

                            .st29 {
                                fill: #F7981C;
                            }

                            .st30 {
                                fill: #EE1B22;
                            }

                            .st31 {
                                fill: #EF3561;
                            }

                            .st32 {
                                fill: none;
                                stroke: #FFFFFF;
                                stroke-width: 2;
                                stroke-miterlimit: 10;
                            }

                            .st33 {
                                fill: #0097D3;
                            }

                            .st34 {
                                fill: #01308A;
                            }

                            .st35 {
                                fill: #019CDE;
                            }

                            .st36 {
                                fill: #FFD049;
                            }

                            .st37 {
                                fill: #16A05D;
                            }

                            .st38 {
                                fill: #4486F4;
                            }

                            .st39 {
                                fill: none;
                            }

                            .st40 {
                                fill: #34A853;
                            }

                            .st41 {
                                fill: #4285F4;
                            }

                            .st42 {
                                fill: #FBBC05;
                            }

                            .st43 {
                                fill: #EA4335;
                            }
                        </style>
                        <path class="st1" d="M23,0H9C4,0,0,4,0,9v14c0,5,4,9,9,9h14c5,0,9-4,9-9V9C32,4,28,0,23,0z" />
                        <path class="st0"
                            d="M26.8,15.4C26.6,15.2,26.3,15,26,15h-5v-3.8c0-0.1,0.1-0.2,0.2-0.2H25c0.6,0,1-0.4,1-1V7c0-0.6-0.4-1-1-1h-4  c-3.3,0-5,2.7-5,6v3h-4c-0.6,0-1,0.4-1,1v3c0,0.6,0.4,1,1,1h4v12h5V20h3c0.4,0,0.8-0.2,0.9-0.6l2-3C27.1,16.1,27,15.7,26.8,15.4z" />
                    </svg>
                </a>
                <a href="" class="fill-blue-700">
                    <svg class="h-7 w-7" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect x="2" y="2" width="28" height="28" rx="6"
                            fill="url(#paint0_radial_87_7153)" />
                        <rect x="2" y="2" width="28" height="28" rx="6"
                            fill="url(#paint1_radial_87_7153)" />
                        <rect x="2" y="2" width="28" height="28" rx="6"
                            fill="url(#paint2_radial_87_7153)" />
                        <path
                            d="M23 10.5C23 11.3284 22.3284 12 21.5 12C20.6716 12 20 11.3284 20 10.5C20 9.67157 20.6716 9 21.5 9C22.3284 9 23 9.67157 23 10.5Z"
                            fill="white" />
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M16 21C18.7614 21 21 18.7614 21 16C21 13.2386 18.7614 11 16 11C13.2386 11 11 13.2386 11 16C11 18.7614 13.2386 21 16 21ZM16 19C17.6569 19 19 17.6569 19 16C19 14.3431 17.6569 13 16 13C14.3431 13 13 14.3431 13 16C13 17.6569 14.3431 19 16 19Z"
                            fill="white" />
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M6 15.6C6 12.2397 6 10.5595 6.65396 9.27606C7.2292 8.14708 8.14708 7.2292 9.27606 6.65396C10.5595 6 12.2397 6 15.6 6H16.4C19.7603 6 21.4405 6 22.7239 6.65396C23.8529 7.2292 24.7708 8.14708 25.346 9.27606C26 10.5595 26 12.2397 26 15.6V16.4C26 19.7603 26 21.4405 25.346 22.7239C24.7708 23.8529 23.8529 24.7708 22.7239 25.346C21.4405 26 19.7603 26 16.4 26H15.6C12.2397 26 10.5595 26 9.27606 25.346C8.14708 24.7708 7.2292 23.8529 6.65396 22.7239C6 21.4405 6 19.7603 6 16.4V15.6ZM15.6 8H16.4C18.1132 8 19.2777 8.00156 20.1779 8.0751C21.0548 8.14674 21.5032 8.27659 21.816 8.43597C22.5686 8.81947 23.1805 9.43139 23.564 10.184C23.7234 10.4968 23.8533 10.9452 23.9249 11.8221C23.9984 12.7223 24 13.8868 24 15.6V16.4C24 18.1132 23.9984 19.2777 23.9249 20.1779C23.8533 21.0548 23.7234 21.5032 23.564 21.816C23.1805 22.5686 22.5686 23.1805 21.816 23.564C21.5032 23.7234 21.0548 23.8533 20.1779 23.9249C19.2777 23.9984 18.1132 24 16.4 24H15.6C13.8868 24 12.7223 23.9984 11.8221 23.9249C10.9452 23.8533 10.4968 23.7234 10.184 23.564C9.43139 23.1805 8.81947 22.5686 8.43597 21.816C8.27659 21.5032 8.14674 21.0548 8.0751 20.1779C8.00156 19.2777 8 18.1132 8 16.4V15.6C8 13.8868 8.00156 12.7223 8.0751 11.8221C8.14674 10.9452 8.27659 10.4968 8.43597 10.184C8.81947 9.43139 9.43139 8.81947 10.184 8.43597C10.4968 8.27659 10.9452 8.14674 11.8221 8.0751C12.7223 8.00156 13.8868 8 15.6 8Z"
                            fill="white" />
                        <defs>
                            <radialGradient id="paint0_radial_87_7153" cx="0" cy="0" r="1"
                                gradientUnits="userSpaceOnUse"
                                gradientTransform="translate(12 23) rotate(-55.3758) scale(25.5196)">
                                <stop stop-color="#B13589" />
                                <stop offset="0.79309" stop-color="#C62F94" />
                                <stop offset="1" stop-color="#8A3AC8" />
                            </radialGradient>
                            <radialGradient id="paint1_radial_87_7153" cx="0" cy="0" r="1"
                                gradientUnits="userSpaceOnUse"
                                gradientTransform="translate(11 31) rotate(-65.1363) scale(22.5942)">
                                <stop stop-color="#E0E8B7" />
                                <stop offset="0.444662" stop-color="#FB8A2E" />
                                <stop offset="0.71474" stop-color="#E2425C" />
                                <stop offset="1" stop-color="#E2425C" stop-opacity="0" />
                            </radialGradient>
                            <radialGradient id="paint2_radial_87_7153" cx="0" cy="0" r="1"
                                gradientUnits="userSpaceOnUse"
                                gradientTransform="translate(0.500002 3) rotate(-8.1301) scale(38.8909 8.31836)">
                                <stop offset="0.156701" stop-color="#406ADC" />
                                <stop offset="0.467799" stop-color="#6A45BE" />
                                <stop offset="1" stop-color="#6A45BE" stop-opacity="0" />
                            </radialGradient>
                        </defs>
                    </svg>
                </a>
            </div>
        </div>
        {{ $slot }}

    </div>

    <footer class="bg-gray-800 border-gray-200 overflow-hidden relative">
        <div class="absolute top-0 bottom-0 h-full w-full">
            <img src="{{ asset('images/footerbg.jpg') }}" class="object-cover opacity-30" alt="">
        </div>
        <div class="custom-shape-divider-top-1695878520 z-0">
            <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120"
                preserveAspectRatio="none">
                <path
                    d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z"
                    class="shape-fill"></path>
            </svg>
        </div>
        <div class="px-4  mx-auto max-w-7xl relative  pt-20 sm:px-6 lg:px-16">
            <div class="flex flex-col items-start justify-between pt-16  gap-y-12 lg:flex-row lg:items-center">
                <div>
                    <div class="flex items-center text-black">
                        <div>
                            <p class="font-semibold text-3xl leading-6 text-white uppercase">
                                SOUTH WAVE BEACH HOUSE
                            </p>

                        </div>
                    </div>
                    <nav class="flex gap-8 mt-11">
                        <a class="relative -my-2 -mx-3 rounded-lg px-3 py-2 text-sm text-white hover:text-blue-600 transition-colors delay-150 hover:delay-[0ms]"
                            href="#"><span class="relative z-10">Alpine</span></a><a
                            class="relative -my-2 -mx-3 rounded-lg px-3 py-2 text-sm text-white hover:text-blue-600 transition-colors delay-150 hover:delay-[0ms]"
                            href="#"><span class="relative z-10">Nextjs</span></a><a
                            class="relative -my-2 -mx-3 rounded-lg px-3 py-2 text-sm text-white hover:text-blue-600 transition-colors delay-150 hover:delay-[0ms]"
                            href="#"><span class="relative z-10">Tailwind</span></a><a
                            class="relative -my-2 -mx-3 rounded-lg px-3 py-2 text-sm text-white hover:text-blue-600 transition-colors delay-150 hover:delay-[0ms]"
                            href="#"><span class="relative z-10">FAQs</span></a>
                    </nav>
                </div>
                <div
                    class="relative mb-2 flex items-center self-stretch p-4 -mx-4 transition-colors group hover:bg-gray-100 sm:self-auto sm:rounded-2xl lg:mx-0 lg:self-auto lg:p-6">
                    <div class="relative flex items-center justify-center flex-none  rounded-xl">
                        <img src="{{ asset('images/logo.png') }}" class="h-16 rounded" alt="">
                    </div>
                    <div class="ml-8 lg:w-64">
                        <p class="text-base font-semibold text-gray-300 group-hover:text-black">
                            <a href="#"><span class="absolute inset-0 sm:rounded-2xl"></span>Stay
                                updated</a>
                        </p>
                        <p class="mt-1 text-sm group-hover:text-gray-800 text-white hover:text-blue-600">
                            Follow us for social media for news and updates
                        </p>
                    </div>
                </div>
            </div>
            <div
                class="flex flex-col items-center pt-8 pb-8 border-t border-gray-200 md:flex-row-reverse md:justify-between md:pt-6">
                <div class="max-w-xl">
                    <form class="flex flex-col items-center justify-center max-w-sm mx-auto" action="">
                        <div class="flex flex-col w-full gap-1 mt-3 sm:flex-row">
                            <input name="email" type="email"
                                class="block w-full px-4 py-2 text-sm font-medium text-gray-800 placeholder-gray-400 bg-white border border-gray-300 rounded-full font-spline focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-600/50 disabled:opacity-50"
                                placeholder="Enter your email..." required=""><button type="button"
                                class="items-center inline-flex  justify-center w-full px-6 py-2.5 text-center text-white duration-200 bg-black border-2 border-black rounded-full nline-flex hover:bg-transparent hover:border-black hover:text-black focus:outline-none lg:w-auto focus-visible:outline-black text-sm focus-visible:ring-black">
                                <div style="position: relative"></div>
                                Subscribe<!-- -->
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"
                                    aria-hidden="true" class="w-4 h-auto ml-2">
                                    <path fill-rule="evenodd"
                                        d="M3 10a.75.75 0 01.75-.75h10.638L10.23 5.29a.75.75 0 111.04-1.08l5.5 5.25a.75.75 0 010 1.08l-5.5 5.25a.75.75 0 11-1.04-1.08l4.158-3.96H3.75A.75.75 0 013 10z"
                                        clip-rule="evenodd"></path>
                                </svg>
                            </button>
                        </div>
                    </form>
                </div>
                <p class="mt-6 text-sm text-white md:mt-0">
                    © Copyright
                    <!-- -->2022
                    <!-- -->. All rights reserved.
                </p>
            </div>
        </div>
    </footer>
</body>

</html>
