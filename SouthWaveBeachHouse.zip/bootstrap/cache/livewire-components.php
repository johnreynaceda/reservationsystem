<?php return array (
  'admin.admin-dashboard' => 'App\\Http\\Livewire\\Admin\\AdminDashboard',
  'admin.guest-list' => 'App\\Http\\Livewire\\Admin\\GuestList',
  'admin.room-add' => 'App\\Http\\Livewire\\Admin\\RoomAdd',
  'admin.room-list' => 'App\\Http\\Livewire\\Admin\\RoomList',
  'guest-dashboard' => 'App\\Http\\Livewire\\GuestDashboard',
  'guest.booked-information' => 'App\\Http\\Livewire\\Guest\\BookedInformation',
);