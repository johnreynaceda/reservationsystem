<x-guests-layout>
    <div class="">
        <livewire:guest-dashboard />
    </div>
</x-guests-layout>
