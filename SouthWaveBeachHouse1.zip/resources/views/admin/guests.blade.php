@section('title', 'Guests')
<x-admin-layout>
    <div>
        <livewire:admin.guest-list />
    </div>
</x-admin-layout>
