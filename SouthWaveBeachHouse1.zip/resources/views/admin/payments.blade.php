@section('title', 'Payments & Billings')
<x-admin-layout>
    <div>
        <div class="mt-10 bg-white p-5 px-7 rounded-xl shadow">

            <div class="mt-5">
                <livewire:admin.admin-dashboard />
            </div>
        </div>
    </div>
</x-admin-layout>
