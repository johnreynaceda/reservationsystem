@section('title', ' Add Room')
<x-admin-layout>
    <div>
        <livewire:admin.room-add />
    </div>
</x-admin-layout>
