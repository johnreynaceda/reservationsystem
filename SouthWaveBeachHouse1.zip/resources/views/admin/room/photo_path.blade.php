<div class="h-24 w-24 my-1 rounded-lg ml-3">
    <img src="{{ Storage::url($getRecord()->photo_path) }}" class="h-full rounded-lg object-cover w-full" alt="">
</div>
