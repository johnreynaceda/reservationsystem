@section('title', 'Room')
<x-admin-layout>
    <div class="rounded-xl shadow">
        <livewire:admin.room-list />
    </div>
</x-admin-layout>
